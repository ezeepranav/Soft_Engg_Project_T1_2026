from flask_restful import Resource
from flask import request
from backend.models import MenuItem

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class SuggestionAPI(Resource):
    def post(self):
        data = request.get_json()
        if not data or "itemId" not in data:
            return {"error": "itemId is required"}, 400

        item_id = data.get("itemId")

        selected_item = MenuItem.query.get(item_id)
        if not selected_item:
            return {"error": "Item not found"}, 404

        all_items = MenuItem.query.filter(MenuItem.id != item_id).all()
        if not all_items:
            return {"suggestions": []}

        def text(item):
            cat_name = item.category.name if item.category else ""
            return f"{item.name} {item.description or ''} {cat_name}"

        corpus = [text(selected_item)] + [text(i) for i in all_items]

        vectors = TfidfVectorizer().fit_transform(corpus)
        scores = cosine_similarity(vectors[0:1], vectors[1:]).flatten()

        ranked = sorted(zip(all_items, scores), key=lambda x: x[1], reverse=True)

        suggestions = [
            {"id": i.id, "name": i.name, "price": i.price}
            for i, _ in ranked[:3]
        ]

        return {
            "itemId": item_id,
            "selectedItem": selected_item.name,
            "suggestions": suggestions,
        }