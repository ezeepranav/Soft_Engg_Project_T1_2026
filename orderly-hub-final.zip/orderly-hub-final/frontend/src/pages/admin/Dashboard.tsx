import { useEffect, useState } from 'react';
import { IndianRupee, ShoppingBag, Users, TrendingUp, ArrowUp } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { apiGetOrders, apiGetMenu, Order } from '@/services/api';

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const iconMap: Record<string, React.ElementType> = { IndianRupee, ShoppingBag, Users, TrendingUp };

const buildWeeklyRevenue = (orders: Order[]) => {
  // Start of current week (Sunday midnight)
  const now = new Date();
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - now.getDay());
  startOfWeek.setHours(0, 0, 0, 0);

  // Bucket revenue by day index (0=Sun … 6=Sat)
  const buckets: Record<number, number> = { 0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0 };

  orders.forEach(o => {
    if (!o.created_at) return;
    const d = new Date(o.created_at);
    if (d >= startOfWeek) {
      buckets[d.getDay()] += o.total ?? 0;
    }
  });

  // Return in Mon–Sun order for nicer display
  const ordered = [1, 2, 3, 4, 5, 6, 0];
  return ordered.map(i => ({ day: DAYS[i], revenue: Math.round(buckets[i]) }));
};

const AdminDashboard = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [menuCount, setMenuCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([apiGetOrders(), apiGetMenu()])
      .then(([ordersRes, menuRes]) => {
        setOrders(ordersRes.orders);
        setMenuCount(menuRes.menu.length);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const totalRevenue = orders.reduce((s, o) => s + (o.total ?? 0), 0);
  const completedOrders = orders.filter(o => o.status === 'completed').length;
  const weeklyData = buildWeeklyRevenue(orders);
  const weeklyTotal = weeklyData.reduce((s, d) => s + d.revenue, 0);

  const stats = [
    { label: 'Total Revenue', value: `₹${totalRevenue.toFixed(0)}`, trend: null, icon: 'IndianRupee' },
    { label: 'Total Orders', value: String(orders.length), trend: null, icon: 'ShoppingBag' },
    { label: 'Menu Items', value: String(menuCount), trend: null, icon: 'Users' },
    { label: 'Completed', value: String(completedOrders), trend: null, icon: 'TrendingUp' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <h1 className="text-2xl font-display">Dashboard</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = iconMap[stat.icon];
          return (
            <div key={stat.label} className="stat-card">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{stat.label}</span>
                <Icon className="h-4 w-4 text-muted-foreground" />
              </div>
              <p className="text-2xl font-display font-bold tabular-nums">{loading ? '…' : stat.value}</p>
            </div>
          );
        })}
      </div>

      <div className="section-card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-display">Weekly Revenue</h3>
          {!loading && (
            <div className="flex items-center gap-1 text-sm font-medium text-success">
              <ArrowUp className="h-3.5 w-3.5" />
              <span className="tabular-nums">₹{weeklyTotal.toFixed(0)} this week</span>
            </div>
          )}
        </div>
        {loading ? (
          <div className="h-64 flex items-center justify-center text-sm text-muted-foreground">Loading…</div>
        ) : weeklyTotal === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center text-sm text-muted-foreground gap-1">
            <p>No revenue recorded this week yet.</p>
            <p className="text-xs">Complete some orders to see the graph populate.</p>
          </div>
        ) : (
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(214, 32%, 91%)" />
                <XAxis dataKey="day" tick={{ fontSize: 12 }} stroke="hsl(215, 16%, 47%)" />
                <YAxis tick={{ fontSize: 12 }} stroke="hsl(215, 16%, 47%)" tickFormatter={(v) => `₹${v}`} />
                <Tooltip formatter={(value: number) => [`₹${value}`, 'Revenue']} contentStyle={{ borderRadius: '8px', border: '1px solid hsl(214, 32%, 91%)', fontSize: '13px' }} />
                <Bar dataKey="revenue" fill="hsl(221, 83%, 53%)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      <div className="section-card">
        <h3 className="text-lg font-display mb-4">Recent Orders</h3>
        {loading ? (
          <p className="text-sm text-muted-foreground text-center py-8">Loading orders…</p>
        ) : orders.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">No orders yet</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr><th>Order ID</th><th>Table</th><th>Total</th><th>Status</th></tr>
              </thead>
              <tbody>
                {orders.slice(0, 10).map((order) => (
                  <tr key={order.id}>
                    <td className="font-medium">#{order.id}</td>
                    <td>Table {order.table_id ?? '—'}</td>
                    <td className="tabular-nums font-medium">₹{(order.total ?? 0).toFixed(2)}</td>
                    <td><span className={`status-badge status-${order.status}`}>{order.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
