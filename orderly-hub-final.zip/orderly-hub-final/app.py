from flask import Flask
from backend.database import db
from backend.config import LocalDevelopmentConfig
from backend.models import User, Role
from flask_security import Security, SQLAlchemyUserDatastore
from flask_cors import CORS
from werkzeug.security import generate_password_hash
 
 
def create_app(test_config=None):
    app = Flask(__name__, template_folder="templates")
    app.config.from_object(LocalDevelopmentConfig)
 
    if test_config:
        app.config.update(test_config)
 
    db.init_app(app)
 
    user_datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, user_datastore)
 
    CORS(app, resources={r"/api/*": {"origins": "*"}}, supports_credentials=True)
 
    from backend.resources import api
    api.init_app(app)
 
    with app.app_context():
        db.create_all()
 
        for name, desc in [
            ("owner", "Restaurant Owner / Admin"),
            ("server", "Waiter / Server"),
            ("customer", "Customer"),
        ]:
            if not user_datastore.find_role(name):
                user_datastore.create_role(name=name, description=desc)
        db.session.commit()
 
        if not test_config:
            if not user_datastore.find_user(email="owner@gmail.com"):
                user_datastore.create_user(
                    email="owner@gmail.com",
                    password=generate_password_hash("1234"),
                    roles=["owner"],
                    name="Owner",
                )
                db.session.commit()
 
            from backend.seed_menu import seed_menu
            seed_menu()
 
        from backend import routes  # noqa: F401
 
    return app
 
 
if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, port=5000)